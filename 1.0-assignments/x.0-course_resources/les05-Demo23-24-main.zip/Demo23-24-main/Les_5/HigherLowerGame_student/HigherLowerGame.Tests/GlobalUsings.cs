global using FluentAssertions;
global using NSubstitute;
global using Xunit;
