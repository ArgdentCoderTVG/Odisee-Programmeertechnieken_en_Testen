global using Xunit;
global using NSubstitute;