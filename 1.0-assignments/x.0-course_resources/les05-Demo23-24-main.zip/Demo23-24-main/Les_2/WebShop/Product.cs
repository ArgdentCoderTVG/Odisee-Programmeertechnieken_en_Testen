﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebShop
{
    public enum Product
    {
        Shampoo, 
        Milk
    }
}
