﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Les3
{
    public class Calculator
    {

        public double Divide(int number1, int number2)
        {
            return number1 / number2;
        }
    }
}
